import 'package:flutter/material.dart';

Color black = Colors.black;
Color blackShade1 = const Color(0xFF101213);
Color white = Colors.white;
Color blue = Colors.blue;
Color grey = Colors.grey;
Color purple = Colors.deepPurple;
